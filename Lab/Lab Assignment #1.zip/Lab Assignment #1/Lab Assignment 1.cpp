/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: alexr
 *
 * Created on January 11, 2021, 3:37 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    float milBdgt=7.0e11f, fedBdgt= 4.1e12f, mlPrcnt;
    mlPrcnt = milBdgt / fedBdgt + 1;
    cout << "The percentage of the military budget to the federal budget is " << mlPrcnt << "%" << endl;

    return 0;
}

