

/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

int main(int argc, char** argv) {
 //Declare Variables
    double test1, test2, test3, test4, test5;
    double average;
    
    //Initialize or input i.e. set variable values
    cout<<"Input 5 numbers to average."<<endl;
    cin>>test1;
    cin>>test2;
    cin>>test3;
    cin>>test4;
    cin>>test5;
    
    
    //Map inputs -> outputs
    average=(test1+test2+test3+test4+test5)/5.0;
    //Display the outputs
    cout<<fixed<<showpoint<<setprecision(1);
    cout<<"The average = "<<average;
    //Exit stage right or left!
    return 0;
}