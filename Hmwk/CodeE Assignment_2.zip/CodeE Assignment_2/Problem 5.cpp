/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip> //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    cout<<"Calculate trig functions"<<endl;
    
    //Declare Variables
    int angle;
    cout<<"Input the angle in degrees."<<endl;
    cin>> angle;
    
    //Initialize or input i.e. set variable value
    cout<<fixed<<showpoint<<setprecision(4);
    cout<<"sin(45) = "<<sin(angle)<<endl;
    cout<<"cos(45) = "<<cos(angle)<<endl;
    cout<<"tan(45) = "<<tan(angle);
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}
