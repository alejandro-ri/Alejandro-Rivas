/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
   
    float number, negSum, posSum, count, posCou, negCou;
    
    cout<<"Input 10 numbers, any order, positive or negative"<<endl;
    //Declare Variables
    for(int i=0; i<10; i++)
    {
    cin>>number;
    
    if(number>=0)
    {
            posSum += number;
            posCou++;
    }
    else
    {
        negSum += number;
        negCou++;
    }    
    }
    count=posCou-negCou;
    cout<<"Negative sum = "<<setw(3)<< negSum<<endl;
    cout<<"Positive sum = "<<setw(3)<< posSum<<endl;
    cout<<"Total sum    = "<<setw(3)<<count;
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}