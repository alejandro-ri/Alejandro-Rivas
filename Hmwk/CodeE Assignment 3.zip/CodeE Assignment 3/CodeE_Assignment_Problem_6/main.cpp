/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    char player1;
    char player2;
    
    cout<<"Rock Paper Scissors Game\n";
    cin>>player1;
    cin>>player1;
    
    if (player1 == 'r' && player2 == 's' || player1 == 'R' && player2 == 'S'){
    cout<<"Rock breaks scissors\n";
    }
    if (player1 == 'p' && player2 == 'r' || player1 == 'P' && player2 == 'R'){
    cout<<"Paper covers rock\n";
    
    }if (player1 == 's' && player2 == 'p' || player1 == 'S' && player2 == 'P'){
    cout<<"Scissors breaks paper\n";
    
    }if (player1 == 'r' && player2 == 'r' || player1 == 'R' && player2 == 'R' || player1 == 's' && player2 == 's' || player1 == 'S' && player2 == 'S' || 
    player1 == 'p' && player2 == 'p' || player1 == 'P' && player2 == 'P'){
    cout<<"Draw!\n";
    
    }else{
        cout<<"Player 2 Wins\n";
    }
    //Declare Variables
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}