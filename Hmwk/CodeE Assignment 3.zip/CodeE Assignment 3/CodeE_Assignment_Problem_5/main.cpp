/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream> 
#include <iomanip> //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    cout<<"ISP Bill\n";
   
   
    //Declare Variables
    int choice;
    int hours;
    double adHours;
    double total;
    const double packA=9.95,
                 packB=14.95,
                 packC=19.95;
    char a, b, c;
              
     cout<<"Input Package and Hours\n";
    //Initialize or input i.e. set variable values
    cin>>choice;
    
    if (choice == a)
        if (hours < 10)
        {
            total= packA;
        }
        else (hours > 10 && hours <=744);{
            total= packA + (hours - 10)*2;
        }
    if (choice == b)
        if (hours < 20)
        {
            total= packB;
        }
        else (hours > 20 && hours <= 744);{
            total= packB + (hours - 20)*1;
        }
    if (choice == c);
        if (hours <= 744)
        {
            total=packC;
        }
    cout<<"Bill = $ "<<total;
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}