/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip> //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    cout<<"Monthly Bank Fees\n";
    cout<<"Input Current Bank Balance and Number of Checks\n";
    
    //Declare Variables
    float balance, checks, fees, total, newBal, monFee=10, lowBal=15;
    cin>>balance>>checks;
    
    if (checks > 20){
        fees=0.10;
        total=checks * fees;
    }
    else if (checks > 20 && checks < 39){
        fees=0.08;
        total=checks * fees;
    } 
     else if (checks > 40 && checks < 59){
        fees=0.06;
        total=checks * fees;
    } 
     else (checks < 60);{
        fees=0.04;
        total=checks * fees;
    } 
    cout<<fixed<<showpoint<<setprecision(2);
    
    if (balance <400){
        lowBal=15;
    }
    else if (balance >= 400){
        lowBal=0;
    }
    
    newBal= balance - total - monFee - lowBal;
    cout<<"Balance     $"<<setw(9)<<balance<<endl;
    cout<<"Check Fee   $"<<setw(9)<<total<<endl;
    cout<<"Monthly Fee $"<<setw(9)<<monFee<<endl;
    cout<<"Low Balance $"<<setw(9)<<lowBal<<endl;
    cout<<"New Balance $"<<setw(9)<<newBal;
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}