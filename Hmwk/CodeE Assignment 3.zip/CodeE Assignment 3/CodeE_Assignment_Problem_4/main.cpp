/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream> 
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    cout<<"Racing Rank Program\n";
    
    //Declare Variables
    string run1;
    string run2;
    string run3;
    double runTime1, runTime2, runTime3;
    
    cout<<"Input 3 Runners\n";
    
    
    //Initialize or input i.e. set variable values
    cin>>run1>>runTime1;
    cin>>run2>>runTime2;
    cin>>run3>>runTime3;
    
    //Map inputs -> outputs
    if (runTime1 < runTime2 && runTime1 < runTime3)
        if (runTime2 < runTime3)
        {
            cout<<"Their names, then their times\n";
            cout<<run1<<setw(7)<<runTime1<<endl;
            cout<<run2<<setw(7)<<runTime2<<endl;
            cout<<run3<<setw(8)<<runTime3;
        }
        else 
        {
            cout<<"Their names, then their times\n";
            cout<<run1<<setw(7)<<runTime1<<endl;
            cout<<run3<<setw(7)<<runTime3<<endl;
            cout<<run2<<setw(8)<<runTime2;
        }
    else if (runTime2 < runTime1 && runTime2 < runTime3)
        if (runTime1 < runTime3)
        {
            cout<<"Their names, then their times\n";
            cout<<run2<<setw(7)<<runTime2<<endl;
            cout<<run1<<setw(7)<<runTime1<<endl;
            cout<<run3<<setw(8)<<runTime3;
        }
        else 
        {
            cout<<"Their names, then their times\n";
            cout<<run2<<setw(7)<<runTime2<<endl;
            cout<<run1<<setw(7)<<runTime1<<endl;
            cout<<run3<<setw(8)<<runTime3;
        }
    else 
        if (runTime1 < runTime2)
        {
            cout<<"Their names, then their times\n";
            cout<<run3<<setw(7)<<runTime3<<endl;
            cout<<run1<<setw(7)<<runTime1<<endl;
            cout<<run2<<setw(8)<<runTime2;
        }
        else 
        {
            cout<<"Their names, then their times\n";
            cout<<run3<<setw(7)<<runTime3<<endl;
            cout<<run2<<setw(7)<<runTime2<<endl;
            cout<<run1<<setw(8)<<runTime1;
        }
    //Display the outputs

    //Exit stage right or left!
    return 0;
}