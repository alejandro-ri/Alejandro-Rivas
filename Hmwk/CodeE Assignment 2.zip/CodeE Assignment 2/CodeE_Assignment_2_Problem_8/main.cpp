//System Libraries
#include <iostream> 
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
 
    float retSal, newSal,  incSal, newMon;
    int annual;
    
    cout<<"Input previous annual salary."<<endl;
    cin>> annual;
    
    float payIncr=.076;
    
    //Declare Variables
    
    cout<<fixed<<showpoint<<setprecision(2);
    //Initialize or input i.e. set variable values
    newSal= (annual *.076) + annual;
    incSal= newSal - annual;
    newMon= (newSal) / 12;
    retSal= (annual / 2) * payIncr;
    
    //Map inputs -> outputs
    cout<<"Retroactive pay    = $"<<setw(7)<<retSal<<endl;
    cout<<"New annual salary  = $"<<setw(7)<<newSal<<endl;
    cout<<"New monthly salary = $"<<setw(7)<<newMon;
    //Display the outputs

    //Exit stage right or left!
    return 0;
}