//System Libraries
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    cout<<"Temperature Converter"<<endl;
    //Declare Variables
    float cel; 
    double fah;
    
    //Initialize or input i.e. set variable values
    cout<<"Input Degrees Fahrenheit"<<endl;
    cin>> fah;
    
    //Map inputs -> outputs
    cout<<fixed<<showpoint<<setprecision(1);
    cel= (fah-32)*(5.0/9.0);
    //Display the outputs
    cout<<fah<<" Degrees Fahrenheit = "<<cel<<" Degrees Centigrade";

    //Exit stage right or left!
    return 0;
}