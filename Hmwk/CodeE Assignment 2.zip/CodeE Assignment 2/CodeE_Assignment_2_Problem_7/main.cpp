//System Libraries
#include <iostream>
#include <iomanip>   
#include <cstdlib>
#include <ctime> //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...
const float cnvengm=453.592;
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    
    cout<<"Program to calculate the limit of Soda Pop Consumption."<<endl;
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    //Declare Variables
    float massMS=35, 
          massKms=5,
          mssCoke=350,
          cncnt8=0.001f,
          wDietr;
    int nCans;
    //Initialize or input i.e. set variable values
    cout<<"Input the desired dieters weight in lbs."<<endl;
    wDietr=rand()%(350-90+1)+90;
    wDietr=200;
    //Map inputs -> outputs
    cout<<"The maximum number of soda pop cans"<<endl;
    nCans=(massKms*wDietr*cnvengm)/(massMS*mssCoke*cncnt8);
    
    //Display the outputs
    cout<<fixed<<showpoint<<setprecision(5);
    cout<<"which can be consumed is "<<nCans<<" cans";

    //Exit stage right or left!
    return 0;
}
