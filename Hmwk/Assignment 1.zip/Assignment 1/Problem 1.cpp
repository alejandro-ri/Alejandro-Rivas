/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>

using namespace std;

int main () {
    unsigned short A,B,sum;
    A=50;
    B=100;
    sum=A+B;
    cout<<A<<" + "<<B<<" = "<<sum;
    return 0;
} 
