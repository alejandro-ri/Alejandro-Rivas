/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>

using namespace std;

int main()
{
    double ttlSal = 8.6e8, percent, income;
    percent = ttlSal * 0.58;
    income = ttlSal - percent;
    cout << "Total Sales: $" << ttlSal << endl;
    cout << "The total income the company generated: $" << income << endl;
    return 0;

}

