/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>

using namespace std;

int main()
{
    unsigned short sum, average;
    sum = 28 + 32 + 37 + 24 + 33;
    average = sum / 5;
    cout <<"The average is " << average << endl;

    return 0;

}

