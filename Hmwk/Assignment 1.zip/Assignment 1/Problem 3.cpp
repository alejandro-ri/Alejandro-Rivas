/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>

using namespace std;

int main()
{
    double ttlSal = 95, salTax, cntTax, total;
    salTax = ttlSal * 0.04;
    cntTax = ttlSal * 0.02;
    total = ttlSal + salTax + cntTax;
    cout << "The total is $" << total << endl;


    return 0;

}

