/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>

using namespace std;

int main()
{
    double ttlSal = 88.67, salTax, tip, total;
    salTax = ttlSal * 0.0675;
    tip = ttlSal * 0.2;
    total = ttlSal + salTax + tip;
    cout << "The total is $" << total << endl;


    return 0;

}
