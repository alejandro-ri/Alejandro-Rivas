

/* 
 * File:   main.cpp
 * Author: alexr
 *
 * Created on January 11, 2021, 2:29 PM
 */

#include <iostream>

using namespace std;

/*
 * 
 */
int main() {
    cout << "   x   " << endl;
    cout << "  xxx  " << endl;
    cout << " xxxxx " << endl;
    cout << "xxxxxxx" << endl;
    cout << " xxxxx " << endl;
    cout << "  xxx  " << endl;
    cout << "   x   " << endl;
    
    return 0;
}
