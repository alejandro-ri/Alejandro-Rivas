/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <iostream>

using namespace std;

int main()
{
    float five, seven, ten;
    five = 1.5 * 5;
    seven = 1.5 * 7;
    ten = 1.5 * 10;
    cout<< "In 5 years the ocean will be " << five << " millimeters higher" << endl;
    cout<< "In 7 years the ocean will be " << seven << " millimeters higher" << endl;
    cout<< "In 10 years the ocean will be " << ten << " millimeters higher" << endl;

    return 0;
}

