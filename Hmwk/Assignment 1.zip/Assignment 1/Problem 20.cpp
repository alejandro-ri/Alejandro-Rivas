/* 
 * File:   main.cpp
 * Author: alexr
 *Created on January 11, 2021, 1:59 PM
 * Purpose: Painters Problem
 */

#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    unsigned short height, 
                   length,
                   pntCov,
                   srfArea,
                   numGlns;
    height=6;
    length=100;
    pntCov=340;
    
    srfArea=2*2*height*length;
    numGlns=srfArea/pntCov+1;
    
    cout<<"Number of Gallons required = " <<numGlns<< "to paint a ";
    cout<<height<<" x "<<length<<"ft^2 fence front and back twice"<<endl;

    return 0;
}

