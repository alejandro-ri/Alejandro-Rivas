/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float liters, miles, lpg;
    float gal=0.264179;
    double mpg;
    char again;
    do
    {
    cout<<"Enter number of liters of gasoline:\n";
    cin>>liters;
    cout<<endl;
    cout<<"Enter number of miles traveled:\n";
    cin>>miles;
    cout<<endl;
    cout<<fixed<<showpoint<<setprecision(2);
    lpg=liters*gal;
    mpg=miles/lpg;
    cout<<"miles per gallon:\n";
    cout<<mpg<<endl;
    cout<<"Again:"<<endl;
    cin>>again;
    } while (again == 'y');
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}