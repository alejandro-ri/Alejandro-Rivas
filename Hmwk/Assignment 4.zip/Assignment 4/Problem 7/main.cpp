/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream> 
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float fliters, fmiles, flpg, sliters, smiles, slpg;
    float gal=0.264179;
    double fmpg, smpg;
    char again;
    do
    {
    cout<<"Car 1"<<endl;
    cout<<"Enter number of liters of gasoline:\n";
    cin>>fliters;
    
    cout<<"Enter number of miles traveled:\n";
    cin>>fmiles;
    
    cout<<fixed<<showpoint<<setprecision(2);
    flpg=fliters*gal;
    fmpg=fmiles/flpg;
    cout<<"miles per gallon: "<<fmpg<<endl;
    cout<<endl;
    
    cout<<"Car 2"<<endl;
    cout<<"Enter number of liters of gasoline:\n";
    cin>>sliters;
    
    cout<<"Enter number of miles traveled:\n";
    cin>>smiles;
    
    cout<<fixed<<showpoint<<setprecision(2);
    slpg=sliters*gal;
    smpg=smiles/slpg;
    cout<<"miles per gallon: "<<smpg<<endl;
    cout<<endl;
    
    if (fmpg < smpg){
        cout<<"Car 2 is more fuel efficient"<<endl;
    }
    else {
        cout<<"Car 1 is more fuel efficient"<<endl;
    }
    cout<<endl;
    
    cout<<"Again:"<<endl;
    cin>>again;
    cout<<endl;
    } while (again == 'y');
    
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs

    //Exit stage right or left!
    return 0;
}