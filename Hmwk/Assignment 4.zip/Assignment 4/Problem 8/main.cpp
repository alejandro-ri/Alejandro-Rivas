/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>
#include <iomanip> //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    double inflation, current, yearago, newprice, twoprice, otherprice;
    char again;
    do
    {
        cout<<"Enter current price:\n";
        cin>>current;
        cout<<"Enter year-ago price:\n";
        cin>>yearago;
        inflation=(current - yearago)/yearago;
        newprice= (inflation * yearago) + yearago;
        twoprice= (inflation * newprice)+ newprice;
        otherprice= (inflation * twoprice) + twoprice;
        
        cout<<fixed<<showpoint<<setprecision(2);
        cout<<"Inflation rate: "<<inflation*100<<"%"<<endl;
        cout<<endl;
        cout<<"Price in one year: $ "<<twoprice<<endl;
        cout<<"Price in two year: $ "<<otherprice<<endl;
        cout<<endl;
        
        cout<<"Again:"<<endl;
        cin>>again;
        
    } while(again == 'y');
    
    
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
return 0;
}